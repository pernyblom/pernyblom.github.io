package com.springworldgames;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Set;

import org.w3c.dom.Element;

import com.springworldgames.LevelEditor.EditModeWithProperties;

public class Level {
	int width;
	int height;

	int index;

	// Stuff without properties
	String[][] backgroundTiles;
	String[][] surfaceTiles;
	String[][] decorations;

	// Stuff that need properties
	LinkedHashMap<String, Object>[][] objectsData;

	private Level() {
	}

	void propertiesArrToJavaScript(LinkedHashMap<String, Object>[][] dataArr,
			StringBuilder builder) {
		builder.append("{\n");
		for (int j = 0; j < height; j++) {
			for (int i = 0; i < width; i++) {
				LinkedHashMap<String, Object> map = dataArr[i][j];
				if (map != null) {
					String symbol = (String) map.get("symbol");
					if (symbol == null) {
						System.out.println(this
								+ " found a map but not a symbol");
					} else {
						for (String key : map.keySet()) {
							builder.append(" \"" + key + "\": " + map.get(key)
									+ ", ");
						}
						builder.append("  \"x\": \"" + i + "\", ");
						builder.append("  \"y\": \"" + j + "\", ");
						builder.append("  \"symbol\": \"" + symbol + "\" ");
					}
				}
			}
		}
		builder.append("}");
	}

	void stringArrToJavaScript(String[][] arr, StringBuilder builder) {
		// [".............",
		// "..f.......g..",
		// "...s........."]
		builder.append("[\n");
		for (int j = 0; j < height; j++) {
			builder.append("\"");
			for (int i = 0; i < width; i++) {
				builder.append(arr[i][j]);
			}
			builder.append("\"");
			if (j < height - 1) {
				builder.append(",");
			}
			builder.append("\n");
		}
		builder.append("]");
	}

	private void createJavaScriptStringVariable(StringBuilder builder,
			String name, String[][] arr) {
		builder.append(name + ": ");
		stringArrToJavaScript(arr, builder);
	}

	private void createJavaScriptPropertiesVariable(StringBuilder builder,
			String name, LinkedHashMap<String, Object>[][] dataArr) {
		builder.append(name + ": ");
		propertiesArrToJavaScript(dataArr, builder);
	}

	public String toJavaScript() {
		StringBuilder builder = new StringBuilder();
		toJavaScript(builder);
		return builder.toString();
	}

	public void toJavaScript(StringBuilder builder) {
		builder.append("{ // Start of level " + index + "\n");
		builder.append("index: " + index + ",\n");
		builder.append("width: " + width + ",\n");
		builder.append("height: " + height + ",\n");
		createJavaScriptStringVariable(builder, "backgroundTiles",
				backgroundTiles);
		builder.append(",\n");
		createJavaScriptStringVariable(builder, "surfaceTiles", surfaceTiles);
		builder.append(",\n");
		createJavaScriptStringVariable(builder, "decorations", decorations);
		builder.append(",\n");
		createJavaScriptPropertiesVariable(builder, "objects", objectsData);
		builder.append(",\n");

		builder.append("} // End of level " + index + "\n");
	}

	public static Level readFromElement(Element element) {
		Level result = new Level();
		result.index = XMLUtils.getIntAttribute("index", element);
		result.width = XMLUtils.getIntAttribute("width", element);
		result.height = XMLUtils.getIntAttribute("height", element);

		ArrayList<Element> children = XMLUtils.getChildrenElements(element);

		// Create the initial empty objects data array
		result.objectsData = new LinkedHashMap[result.width][result.height];
		for (int i = 0; i < result.width; i++) {
			result.objectsData[i] = new LinkedHashMap[result.height];
		}

		for (Element e : children) {
			String tagName = e.getTagName();
			if (tagName.equals("backgroundTiles")) {
				result.backgroundTiles = getInfoTagString(e, result.width,
						result.height);
			} else if (tagName.equals("surfaceTiles")) {
				result.surfaceTiles = getInfoTagString(e, result.width,
						result.height);
			} else if (tagName.equals("objects")) {
				result.objectsData = getMapDataTags(e, ObjectsEditMode.NONE,
						result.width, result.height);
			} else if (tagName.equals("decorations")) {
				result.decorations = getInfoTagString(e, result.width,
						result.height);
			} else {
				System.out.println("unknown level tag " + tagName);
			}
		}

		return result;
	}

	private static LinkedHashMap<String, Object>[][] getMapDataTags(Element e,
			EditModeWithProperties mode, int width, int height) {
		LinkedHashMap<String, Object>[][] result = new LinkedHashMap[width][height];
		for (int i = 0; i < width; i++) {
			result[i] = new LinkedHashMap[height];
		}
		LinkedHashMap<String, ? extends EditModeWithProperties> stringToModeMap = mode
				.getStringToModeMap();

		ArrayList<Element> children = XMLUtils.getChildrenElements(e);
		for (Element d : children) {
			String symbol = d.getAttribute("symbol");
			int x = XMLUtils.getIntAttribute("x", d);
			int y = XMLUtils.getIntAttribute("y", d);

			EditModeWithProperties specificMode = stringToModeMap.get(symbol);
			LinkedHashMap<String, Object> defaultProperties = specificMode
					.getNewDefaultProperties();

			LinkedHashMap<String, Object> parsedProperties = new LinkedHashMap<String, Object>();
			result[x][y] = parsedProperties;

			parsedProperties.put("x", x);
			parsedProperties.put("y", y);
			for (String key : defaultProperties.keySet()) {

				try {
					Object defaultValue = defaultProperties.get(key);
					Object parsedValue = null;
					if (defaultValue instanceof Double) {
						if (d.hasAttribute(key)) {
							parsedValue = XMLUtils.getDoubleAttribute(key, d);
						}
					} else if (defaultValue instanceof Integer) {
						if (d.hasAttribute(key)) {
							parsedValue = XMLUtils.getIntAttribute(key, d);
						}
					} else if (defaultValue instanceof String) {
						if (d.hasAttribute(key)) {
							parsedValue = d.getAttribute(key);
						}
					}

					if (parsedValue != null) {
						parsedProperties.put(key, parsedValue);
					} else {
						System.out
								.println(Level.class
										+ " parsed value was null. Setting default for "
										+ key + ": "
										+ defaultProperties.get(key));
						parsedValue = defaultProperties.get(key);
					}
				} catch (Exception ex) {
					System.out.println(Level.class
							+ " problem when reading attribute " + key);
					ex.printStackTrace();
				}
			}
		}
		return result;
	}

	private static String[][] getInfoTagString(Element e, int width, int height) {
		String attr = XMLUtils.getStringAttribute("info", e);
		return parseStringArr(attr, width, height);
	}

	private static String[][] parseStringArr(String str, int width, int height) {
		String[] substrings = str.split(":");

		String[][] result = new String[width][height];
		for (int j = 0; j < height; j++) {
			String s;
			if (j < substrings.length) {
				s = substrings[j];
			} else {
				StringBuilder builder = new StringBuilder();
				StringUtils.appendMany(builder, width, ".");
				s = builder.toString();
			}
			for (int i = 0; i < width; i++) {
				if (i < s.length()) {
					result[i][j] = "" + s.charAt(i);
				} else {
					result[i][j] = ".";
				}
			}
		}
		return result;
	}

	public String toXml() {
		StringBuilder builder = new StringBuilder();
		toXml(builder);
		return builder.toString();
	}

	public void toXml(StringBuilder builder) {
		builder.append("<level " + " index=\"" + index + "\" width=\"" + width
				+ "\" height=\"" + height + "\" >\n");
		addStringInfoTag(builder, "backgroundTiles", backgroundTiles);
		addStringInfoTag(builder, "surfaceTiles", surfaceTiles);
		addStringInfoTag(builder, "decorations", decorations);
		addMapInfoTag(builder, "objects", objectsData);
		builder.append("</level>\n");
	}

	void addStringInfoTag(StringBuilder builder, String tagName, String[][] arr) {
		builder.append("  <" + tagName + " info=\"");
		flatten(builder, arr, ":");
		builder.append("\" />\n");
	}

	void addMapInfoTag(StringBuilder builder, String tagName,
			LinkedHashMap<String, Object>[][] data) {
		builder.append("  <" + tagName + ">\n");
		for (int j = 0; j < data[0].length; j++) {
			for (int i = 0; i < data.length; i++) {
				LinkedHashMap<String, Object> map = data[i][j];
				if (map != null) {
					builder.append("    <data ");
					for (String p : map.keySet()) {
						builder.append(" " + p + "=\"" + map.get(p) + "\" ");
					}
					builder.append(" />\n");
				}
			}
		}
		builder.append("  </" + tagName + ">\n");
	}

	void flatten(StringBuilder builder, String[][] arr, String separator) {
		for (int j = 0; j < arr[0].length; j++) {
			for (int i = 0; i < arr.length; i++) {
				String str = arr[i][j];
				builder.append(XMLUtils.escape(str));
			}
			if (j < arr[0].length - 1) {
				builder.append(separator);
			}
		}
	}

	public boolean equals(Object obj) {
		if (obj instanceof Level) {
			Level level = (Level) obj;
			if (!stringArrEquals(level.backgroundTiles, backgroundTiles)) {
				return false;
			}
			if (!stringArrEquals(level.surfaceTiles, surfaceTiles)) {
				return false;
			}
			if (!stringArrEquals(level.decorations, decorations)) {
				return false;
			}
			if (!mapArrEquals(level.objectsData, objectsData)) {
				return false;
			}

			return level.width == width && level.height == height
					&& level.index == index;
		}
		return false;
	}

	public boolean mapEquals(LinkedHashMap<String, Object> map1,
			LinkedHashMap<String, Object> map2) {
		if (map1 == map2) {
			// Also checks for null
			return true;
		}
		if (map1 == null || map2 == null) {
			return false;
		}
		Set<String> keySet1 = map1.keySet();
		Set<String> keySet2 = map2.keySet();
		if (keySet1.size() == keySet2.size()) {
			for (String key1 : keySet1) {
				if (keySet2.contains(key1)) {
					Object v1 = map1.get(key1);
					Object v2 = map2.get(key1);
					if (v1 != null && v2 != null && v1.equals(v2)) {
						return true;
					} else {
						return false;
					}
				} else {
					return false;
				}
			}
		}
		return false;
	}

	public boolean mapArrEquals(LinkedHashMap<String, Object>[][] arr1,
			LinkedHashMap<String, Object>[][] arr2) {
		if (arr1.length == arr2.length) {
			for (int i = 0; i < arr1.length; i++) {
				LinkedHashMap<String, Object>[] subArr1 = arr1[i];
				LinkedHashMap<String, Object>[] subArr2 = arr2[i];
				if (subArr1.length == subArr2.length) {
					for (int j = 0; j < subArr1.length; j++) {
						if (!mapEquals(subArr1[j], subArr2[j])) {
							return false;
						}
					}
				} else {
					return false;
				}
			}
			return true;
		}
		return false;
	}

	public boolean stringArrEquals(String[][] arr1, String[][] arr2) {
		if (arr1.length == arr2.length) {
			for (int i = 0; i < arr1.length; i++) {
				String[] subArr1 = arr1[i];
				String[] subArr2 = arr2[i];
				if (subArr1.length == subArr2.length) {
					for (int j = 0; j < subArr1.length; j++) {
						if (!subArr1[j].equals(subArr2[j])) {
							return false;
						}
					}
				} else {
					return false;
				}
			}
			return true;
		}
		return false;
	}

	String[][] copyStringArr(String[][] toCopy) {
		String[][] result = new String[toCopy.length][toCopy[0].length];
		for (int i = 0; i < toCopy.length; i++) {
			for (int j = 0; j < toCopy[i].length; j++) {
				result[i][j] = toCopy[i][j];
			}
		}
		return result;
	}

	LinkedHashMap<String, Object>[][] copyMapArr(
			LinkedHashMap<String, Object>[][] toCopy) {
		if (toCopy == null) {
			System.out.println(this + " trying to copy null map");
		} else if (toCopy[0] == null) {
			System.out.println(this + " could not find sub array in map array");
		}

		LinkedHashMap<String, Object>[][] result = new LinkedHashMap[toCopy.length][toCopy[0].length];
		for (int i = 0; i < toCopy.length; i++) {
			for (int j = 0; j < toCopy[i].length; j++) {
				if (toCopy[i][j] != null) {
					LinkedHashMap<String, Object> copy = new LinkedHashMap<String, Object>();
					copy.putAll(toCopy[i][j]);
				}
				result[i][j] = toCopy[i][j];
			}
		}
		return result;
	}

	public Level copy() {
		Level result = new Level(index, width, height);
		result.backgroundTiles = copyStringArr(backgroundTiles);
		result.surfaceTiles = copyStringArr(surfaceTiles);
		result.decorations = copyStringArr(decorations);
		result.objectsData = copyMapArr(objectsData);
		result.width = width;
		result.height = height;
		result.index = index;
		return result;
	}

	public Level(int index, int w, int h) {
		this.width = w;
		this.height = h;
		backgroundTiles = new String[w][h];
		surfaceTiles = new String[w][h];
		decorations = new String[w][h];
		objectsData = new LinkedHashMap[w][h];

		for (int i = 0; i < w; i++) {
			objectsData[i] = new LinkedHashMap[h];
			for (int j = 0; j < h; j++) {
				objectsData[i][j] = null;
				backgroundTiles[i][j] = BackgroundTilesEditMode.ROCK
						.getString();
				surfaceTiles[i][j] = SurfaceTilesEditMode.NONE.getString();
				decorations[i][j] = DecorationsEditMode.NONE.getString();
			}
		}

		this.index = index;
	}

	public String[][] getBackgroundTiles() {
		return backgroundTiles;
	}

	public String[][] getSurfaceTiles() {
		return surfaceTiles;
	}

	public String[][] getDecorations() {
		return decorations;
	}

	public LinkedHashMap<String, Object>[][] getObjectsData() {
		return objectsData;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public static void main(String[] args) {
		Level level = new Level(0, 20, 30);
		StringBuilder builder = new StringBuilder();
		level.toJavaScript(builder);
		System.out.println(builder.toString());
	}
}

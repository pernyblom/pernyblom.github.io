package com.springworldgames;

import java.awt.Color;
import java.util.LinkedHashMap;

import com.springworldgames.LevelEditor.EditModeInterface;

public enum SurfaceTilesEditMode implements EditModeInterface {
	NONE(".", "None", new Color(0, 0, 0, 0)), // 
	GRASS("g", "Grass", Color.green), //
	;

	private String string;
	private String guiString;
	private Color color;

	private static LinkedHashMap<String, SurfaceTilesEditMode> stringToModeMap;

	private SurfaceTilesEditMode(String string, String guiString, Color color) {
		this.string = string;
		this.guiString = guiString;
		this.color = color;
	}

	public Color getColor() {
		return color;
	}

	public String getString() {
		return string;
	}

	public String getGuiString() {
		return guiString;
	}

	public static SurfaceTilesEditMode getFromString(String tileString) {
		if (stringToModeMap == null) {
			stringToModeMap = new LinkedHashMap<String, SurfaceTilesEditMode>();
			for (SurfaceTilesEditMode mode : values()) {
				stringToModeMap.put(mode.getString(), mode);
			}
		}
		return stringToModeMap.get(tileString);
	}

}

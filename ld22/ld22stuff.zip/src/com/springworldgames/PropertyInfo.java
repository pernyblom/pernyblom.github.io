package com.springworldgames;

public class PropertyInfo {
	String name;
	Object defaultValue;
	
	public PropertyInfo(String name, Object defaultValue) {
		this.name = name;
		this.defaultValue = defaultValue;
	}

	
}

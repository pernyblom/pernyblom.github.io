package com.springworldgames;

import java.util.LinkedHashMap;
import java.util.Set;

import com.springworldgames.LevelEditor.EditModeInterface;

public enum DecorationsEditMode implements EditModeInterface {
	NONE(".", "None", "None"), // 
	HEALTH_PICKUP_1("h", "Health 1", "heal"), // 
	;

	private static Set<String> possibleSymbols;

	private static LinkedHashMap<String, DecorationsEditMode> stringToModeMap;
	private String string;
	private String guiString;
	private String shortString;

	private DecorationsEditMode(String string, String guiString,
			String shortString) {
		this.string = string;
		this.guiString = guiString;
		this.shortString = shortString;
	}

	public String getShortString() {
		return shortString;
	}

	public String getGuiString() {
		return guiString;
	}

	public String getString() {
		return string;
	}

	public static DecorationsEditMode getFromString(String tileString) {
		if (stringToModeMap == null) {

			possibleSymbols = Utils.getPossibleSymbols();
			for (DecorationsEditMode mode : values()) {
				possibleSymbols.remove(mode.getString());
			}

			stringToModeMap = new LinkedHashMap<String, DecorationsEditMode>();
			for (DecorationsEditMode mode : values()) {
				if (stringToModeMap.containsKey(mode.getString())) {
					System.out.println("Duplicate key in "
							+ DecorationsEditMode.class + " "
							+ mode.getString() + " " + mode);
					System.out.println("symbols left: " + possibleSymbols);
				}
				stringToModeMap.put(mode.getString(), mode);
			}
		}
		return stringToModeMap.get(tileString);
	}

}

package com.springworldgames;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.Date;

import javax.imageio.ImageIO;

public class TimeLapse {

	public static String dir = "../Data/LD22Timelapse/";

	public static void runTimelapseCapture(int realSeconds, int fps,
			int videoLengthSeconds) throws Exception {

		int totalFrameCount = videoLengthSeconds * fps;

		double secondsBetweenEachTake = realSeconds
				/ (double) (totalFrameCount * fps);

		System.out.println("Seconds between: " + secondsBetweenEachTake
				+ " Total frames: " + totalFrameCount);

		// double test = secondsBetweenEachTake * totalFrameCount;
		// System.out.println("Test: " + test);

		Robot robot = new Robot();
		int width = 1440;
		int height = 900;

		Font font = Font.createFont(Font.TRUETYPE_FONT, new File(
				"C:/Windows/Fonts/impact.ttf"));
		Font fontToUse = font.deriveFont((float) 20.0);

		BufferedImage image = robot.createScreenCapture(new Rectangle(0, 0,
				width, height));

		Date date = new Date();
		String dateString = date.toString() + " (In Sweden)";

		Graphics2D g = image.createGraphics();
		FontMetrics fm = g.getFontMetrics(fontToUse);
		Rectangle2D bounds = fm.getStringBounds(dateString, g);

		int stringWidth = (int) bounds.getWidth();
		int x = width - 400;
		int y = 20;

		g.setColor(Color.lightGray);
		g.fillRect(x - 5, y - 20, stringWidth + 10, 30);

		g.setFont(fontToUse);
		g.setColor(Color.black);
		g.drawString(dateString, x, y);
		g.setColor(Color.white);
		g.drawString(dateString, x - 2, y - 2);

		ImageIO.write(image, "png", new File(dir + "tl_"
				+ System.currentTimeMillis() + ".png"));

	}

	public static void createTimelapseVideo(long fromMillis, long toMillis,
			int fps) throws Exception {

		// Gather all filenames that are within the time period and sort them
		ArrayList<String> filenames = new ArrayList<String>();

		// Go through each file and add the image to the video stream

		File videoFile = new File("video_" + fromMillis + "_" + toMillis
				+ ".avi");
		AVIOutputStream videoOut = new AVIOutputStream(videoFile,
				AVIOutputStream.VideoFormat.PNG);
		videoOut.setFrameRate(fps);
		// videoOut.setVideoCompressionQuality((float) videoQuality);
		videoOut.setTimeScale(1);

		for (String filename : filenames) {
			BufferedImage image = ImageIO.read(new File(dir + filename));
			videoOut.writeFrame(image);
		}

		videoOut.close();

	}

	public static void main(String[] args) throws Exception {
		int realSeconds = 60 * 60 * 48;
		int fps = 10; // In the final video
		int videoLengthSeconds = 60 * 5; // Five minutes
		runTimelapseCapture(realSeconds, fps, videoLengthSeconds);
		createTimelapseVideo(0, Long.MAX_VALUE, fps);
	}

}

package com.springworldgames;

import java.util.LinkedHashMap;
import java.util.Set;

import com.springworldgames.LevelEditor.EditModeWithProperties;

public enum ObjectsEditMode implements EditModeWithProperties {
	//
	NONE(".", "None", "None", (PropertyInfo) null), //
	STUFF("s", "Stuff 1", "stu1", new PropertyInfo("health", 1.0),
			new PropertyInfo("damageLevel", 3)), //
	STUFF_2("t", "Stuff 2", "stu2", new PropertyInfo("message", "Hello")), // 
	// 
	;

	private static LinkedHashMap<String, ObjectsEditMode> stringToModeMap;

	private static Set<String> possibleSymbols;

	private int width = 1;
	private int height = 1;
	private String string;
	private String guiString;
	private String shortString;
	private PropertyInfo[] properties;

	@Override
	public LinkedHashMap<String, ? extends EditModeWithProperties> getStringToModeMap() {
		setStringToModeMapIfNecessary();
		return stringToModeMap;
	}

	@Override
	public LinkedHashMap<String, Object> getNewDefaultProperties() {
		if (properties == null || properties.length == 0
				|| (properties.length == 1 && properties[0] == null)) {
			return null;
		}

		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();

		// Adding stuff that are common
		result.put("symbol", string);
		result.put("x", 0);
		result.put("y", 0);
		result.put("w", width);
		result.put("h", height);

		for (PropertyInfo p : properties) {
			result.put(p.name, p.defaultValue);
		}
		return result;
	}

	public PropertyInfo[] getProperties() {
		return properties;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	private ObjectsEditMode(String string, String guiString,
			String shortString, PropertyInfo... properties) {
		this(string, guiString, shortString, 1, 1, properties);
	}

	private ObjectsEditMode(String string, String guiString,
			String shortString, int width, int height,
			PropertyInfo... properties) {
		this.string = string;
		this.guiString = guiString;
		this.shortString = shortString;
		this.width = width;
		this.height = height;
		this.properties = properties;
	}

	public String getString() {
		return string;
	}

	public String getGuiString() {
		return guiString;
	}

	public String getShortString() {
		return shortString;
	}

	public static void setStringToModeMapIfNecessary() {
		if (stringToModeMap == null) {
			possibleSymbols = Utils.getPossibleSymbols();
			for (ObjectsEditMode mode : values()) {
				possibleSymbols.remove(mode.getString());
			}

			stringToModeMap = new LinkedHashMap<String, ObjectsEditMode>();
			for (ObjectsEditMode mode : values()) {
				if (stringToModeMap.containsKey(mode.getString())) {
					System.out.println("duplicate key in "
							+ ObjectsEditMode.class.getName() + " "
							+ mode.getString() + " for mode " + mode);
					System.out.println("symbols left: " + possibleSymbols);
				}
				stringToModeMap.put(mode.getString(), mode);
			}
		}
	}
	
	public static ObjectsEditMode getFromString(String tileString) {
		setStringToModeMapIfNecessary();
		return stringToModeMap.get(tileString);
	}

}

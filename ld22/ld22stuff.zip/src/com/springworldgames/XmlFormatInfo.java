package com.springworldgames;
public class XmlFormatInfo {

	public int maxColumnWidth = 80;
	public int indentStep = 4;
}

var Sound = {};

Sound.SOUND_ID_1 = 0;
Sound.SOUND_ID_2 = 1;
Sound.MUSIC_ID_1 = 2;

Sound.sounds = [];
Sound.loaded = [];
Sound.allLoaded =false;
Sound.smInitiated = false;
Sound.loadedSounds = 0;
Sound.percentDone = 0.0;

Sound.mute = false;

Sound.init = function() {

	soundManager.debugMode = false;
	soundManager.url = '';
	soundManager.useHTML5Audio = true;
	soundManager.preferFlash = false;
	
	soundManager.onready(function() {
		var sounds = [
		{name: "sound1", intId: Sound.SOUND_ID_1, filename: "sound1.mp3"},
		{name: "sound2", intId: Sound.SOUND_ID_2, filename: "sound2.mp3"}
		];
		
		Sound.soundInfoArray = sounds;
		for (var i = 0; i < sounds.length; i++) {
			var soundInfo = sounds[i];
			var sound = soundManager.createSound({
				id: soundInfo.name,
				url: soundInfo.filename,
				autoLoad: true,
				autoPlay: false,
				onload: function() {
					Sound.loaded[soundInfo.intId] = true;
					Sound.loadedSounds++;
					Sound.percentDone = Math.round(100.0 * Math.min(1.0, (Sound.loadedSounds / Sound.soundInfoArray.length)));
				},
				volume: 50
			});
			Sound.sounds[soundInfo.intId] = sound;
		}
		Sound.smInitiated = true;
	});

}

Sound.isPlaying = function(soundId) {
	if (Sound.smInitiated) {
		var sound = Sound.sounds[soundId];
		if (typeof sound != "undefined") {
			return sound.playState == 1;
		}
	}
	return false;
}

Sound.play = function(soundId, options) {
	if (Sound.smInitiated && !Sound.mute) {
		if (options) {
			Sound.sounds[soundId].play(options);
		} else {
			Sound.sounds[soundId].play();
		}
	}
}

Sound.stop = function(soundId) {
	if (Sound.smInitiated) {
		// if (Sound.loaded[soundId]) {
		Sound.sounds[soundId].stop();
		// }
	}
}

Sound.muteSound = function() {
	Sound.stop(Sound.MUSIC_ID_1);
	Sound.mute = true;
}

Sound.unMuteSound = function() {
	Sound.mute = false;
}


// Font stuff
var Font = {};
Font.fontStringArr = ["ABCDEFGHIJKLMNOPQRSTUVWXYZ", "0123456789.,!><+-;:?*"];
Font.fontMap = new Map();


Font.init = function() {
	var arrs = [Font.fontStringArr];
	var maps = [Font.fontMap];
	for (var k = 0; k<arrs.length; k++) {
		var arr = arrs[k];
		var map = maps[k];
		for (var i =0; i<arr.length; i++) {
			var str = arr[i];
			for (var j=0; j<str.length; j++) {
				var ch = str.charAt(j);
				map.put(ch, [j, i]);
			}
		}
	}
}

Font.drawString = function(x, y, str) {
	for (var i=0; i<str.length; i++) {
		var ch = str.charAt(i);
		var coords = Font.fontMap.get(ch);
		if (typeof coords == "undefined") {
		} else {
			var size = 8;
			ctx.drawImage(ImageHandler.images.font, coords[0] * 8, coords[1] * 8, 8, 8, x + i * size, y, size, size);
		}
	}
}

